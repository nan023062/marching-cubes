"""Tileable 3D fbm noise + UV 光栅化烘焙切线空间法线贴图。

数学约束（边界连续性硬约束）：
  fbm 的每个 octave k 周期 = freq * 2^k（必为整数）。lattice hash 用 (ix mod period, iy mod period, iz mod period)。
  → 整体周期为 1 的整数倍 → f(0, y, z) ≡ f(1, y, z) 三轴均成立。

切线空间法线编码（简化版，依赖 architecture 中 "MQ 地形 mesh 几乎水平" 的前提）：
  tangent ≈ +X，bitangent ≈ +Y（Blender 局部），normal ≈ +Z（Blender Z up）
  → 切线空间法线 = normalize((-∂fbm/∂x, -∂fbm/∂y, 1))

向量化：sample/gradient 接受 numpy array（同 shape），返回 array — 光栅化时一次处理一个三角形 bbox 内全部像素。
"""

import numpy as np


# ── 整数 hash → [0,1) 三分量 ──────────────────────────────────────────────────
# 简单 PCG-like multi-prime hash，无需依赖 hashlib（性能 + 可向量化）

_HX = np.uint32(0x27D4EB2D)
_HY = np.uint32(0x165667B1)
_HZ = np.uint32(0x9E3779B1)
_HS = np.uint32(0x85EBCA77)
_M1 = np.uint32(0x7FEB352D)
_M2 = np.uint32(0x846CA68B)


def _hash_grad(ix, iy, iz, seed):
    """整数 (ix, iy, iz) → 单位长度 3D 梯度向量（同 shape numpy array）。

    向量化：ix/iy/iz 可以是 ndarray（同 shape），返回 (gx, gy, gz) 三个同 shape array。
    """
    # 强制 uint32 算术（避免 numpy 把 int32 + uint32 提升到 int64）
    ix32 = np.asarray(ix, dtype=np.int64).astype(np.uint32, copy=False)
    iy32 = np.asarray(iy, dtype=np.int64).astype(np.uint32, copy=False)
    iz32 = np.asarray(iz, dtype=np.int64).astype(np.uint32, copy=False)
    s32  = np.uint32(seed)

    # uint32 模 2^32 算术：环绕乘法是设计行为，禁掉 overflow warning
    with np.errstate(over='ignore'):
        h = ix32 * _HX + iy32 * _HY + iz32 * _HZ + s32 * _HS
        h ^= h >> np.uint32(15)
        h = h * _M1
        h ^= h >> np.uint32(13)
        h = h * _M2
        h ^= h >> np.uint32(16)

        # 由 h 派生 3 个独立分量 → [-1, 1]
        h1 = h
        h2 = h * np.uint32(0xC2B2AE35)
        h3 = (h ^ np.uint32(0xCC9E2D51)) * np.uint32(0x1B873593)
    inv = np.float64(2.0) / np.float64(0xFFFFFFFF)
    gx = h1.astype(np.float64) * inv - 1.0
    gy = h2.astype(np.float64) * inv - 1.0
    gz = h3.astype(np.float64) * inv - 1.0

    # 归一化到单位长度（避免出现 0 长度）
    length = np.sqrt(gx * gx + gy * gy + gz * gz)
    length = np.where(length < 1e-9, 1.0, length)
    return gx / length, gy / length, gz / length


def _smoothstep5(t):
    """Quintic smoothstep 6t^5 - 15t^4 + 10t^3。"""
    return t * t * t * (t * (t * 6.0 - 15.0) + 10.0)


def _periodic_perlin(x, y, z, period, seed):
    """周期为 period 的 3D Perlin noise（lattice gradient + smoothstep + 三线性插值）。

    输入 x/y/z：numpy array 同 shape（或标量，会自动 broadcast）。
    输出：同 shape 的 noise 值，范围近似 [-1, 1]。
    period：正整数；lattice hash 用 (ix mod period) 三轴均如此 → 周期 tileable。
    """
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    z = np.asarray(z, dtype=np.float64)

    ix0 = np.floor(x).astype(np.int64)
    iy0 = np.floor(y).astype(np.int64)
    iz0 = np.floor(z).astype(np.int64)
    fx = x - ix0
    fy = y - iy0
    fz = z - iz0

    u = _smoothstep5(fx)
    v = _smoothstep5(fy)
    w = _smoothstep5(fz)

    # 8 角点 hash + 梯度·偏移向量
    p = int(period)

    def corner(dx, dy, dz):
        ix = (ix0 + dx) % p
        iy = (iy0 + dy) % p
        iz = (iz0 + dz) % p
        gx, gy, gz_ = _hash_grad(ix, iy, iz, seed)
        return gx * (fx - dx) + gy * (fy - dy) + gz_ * (fz - dz)

    n000 = corner(0, 0, 0); n100 = corner(1, 0, 0)
    n010 = corner(0, 1, 0); n110 = corner(1, 1, 0)
    n001 = corner(0, 0, 1); n101 = corner(1, 0, 1)
    n011 = corner(0, 1, 1); n111 = corner(1, 1, 1)

    nx00 = n000 + u * (n100 - n000)
    nx10 = n010 + u * (n110 - n010)
    nx01 = n001 + u * (n101 - n001)
    nx11 = n011 + u * (n111 - n011)

    nxy0 = nx00 + v * (nx10 - nx00)
    nxy1 = nx01 + v * (nx11 - nx01)

    return nxy0 + w * (nxy1 - nxy0)


class TileableNoiseField:
    """周期 1 的 3D fbm 噪声场。

    sample(0, y, z) ≡ sample(1, y, z) 严格成立（三轴均），证明：
      fbm = Σ_{k=0..octaves-1} amp^k * periodic_perlin(p * freq*2^k, period = freq*2^k)
      每个 octave 周期 (freq*2^k) 是 1 的整数倍 → 周期 1 整体保持。
    """

    def __init__(self, seed: int, octaves: int, amplitude: float, frequency: int):
        # 必须整数：保证 (freq * 2^k) 也为整数 → mod period 严格 tileable
        assert isinstance(frequency, int) and frequency >= 1, \
            f"frequency must be int >= 1, got {frequency!r}"
        assert isinstance(octaves, int) and octaves >= 1, \
            f"octaves must be int >= 1, got {octaves!r}"
        self.seed = int(seed) & 0xFFFFFFFF
        self.octaves = octaves
        self.amplitude = float(amplitude)
        self.frequency = frequency

    def sample(self, x, y, z):
        """fbm 采样。x/y/z：标量或 numpy array（同 shape）。返回同 shape ndarray。"""
        x = np.asarray(x, dtype=np.float64)
        y = np.asarray(y, dtype=np.float64)
        z = np.asarray(z, dtype=np.float64)
        out = np.zeros_like(x)
        for k in range(self.octaves):
            f = self.frequency * (1 << k)
            amp = self.amplitude ** k
            out += amp * _periodic_perlin(x * f, y * f, z * f, f, self.seed + k)
        return out

    def gradient(self, x, y, z, eps: float = 1e-3):
        """中心差分 3D 梯度，返回 (∂/∂x, ∂/∂y, ∂/∂z)。"""
        gx = (self.sample(x + eps, y, z) - self.sample(x - eps, y, z)) / (2.0 * eps)
        gy = (self.sample(x, y + eps, z) - self.sample(x, y - eps, z)) / (2.0 * eps)
        gz = (self.sample(x, y, z + eps) - self.sample(x, y, z - eps)) / (2.0 * eps)
        return gx, gy, gz


# ── UV 光栅化 + 切线空间法线烘焙 ──────────────────────────────────────────────


def _rasterize_triangle(pixels, res, uv0, uv1, uv2, v0, v1, v2, noise_field):
    """光栅化 UV 三角形，对覆盖 pixel 算 noise gradient → 编码切线空间法线。

    pixels: (res, res, 4) uint8，原地写入 R/G/B；A 不动。
    pixels 行 r 对应 image_v = r / (res - 1)（Blender image.pixels y-up，row 0 在底部）。
    """
    px0 = (uv0[0] * (res - 1), uv0[1] * (res - 1))
    px1 = (uv1[0] * (res - 1), uv1[1] * (res - 1))
    px2 = (uv2[0] * (res - 1), uv2[1] * (res - 1))

    minx = max(int(np.floor(min(px0[0], px1[0], px2[0]))), 0)
    maxx = min(int(np.ceil (max(px0[0], px1[0], px2[0]))), res - 1)
    miny = max(int(np.floor(min(px0[1], px1[1], px2[1]))), 0)
    maxy = min(int(np.ceil (max(px0[1], px1[1], px2[1]))), res - 1)
    if minx > maxx or miny > maxy:
        return

    xx, yy = np.meshgrid(
        np.arange(minx, maxx + 1),
        np.arange(miny, maxy + 1),
        indexing='xy')
    px = xx.astype(np.float64)
    py = yy.astype(np.float64)

    # 2D 重心坐标
    den = (px1[1] - px2[1]) * (px0[0] - px2[0]) + (px2[0] - px1[0]) * (px0[1] - px2[1])
    if abs(den) < 1e-12:
        return
    inv_den = 1.0 / den
    w0 = ((px1[1] - px2[1]) * (px - px2[0]) + (px2[0] - px1[0]) * (py - px2[1])) * inv_den
    w1 = ((px2[1] - px0[1]) * (px - px2[0]) + (px0[0] - px2[0]) * (py - px2[1])) * inv_den
    w2 = 1.0 - w0 - w1

    # 容差：避免相邻三角形接缝处漏 pixel
    tol = -1e-6
    inside = (w0 >= tol) & (w1 >= tol) & (w2 >= tol)
    if not inside.any():
        return

    # 3D 位置插值
    x3 = w0 * v0[0] + w1 * v1[0] + w2 * v2[0]
    y3 = w0 * v0[1] + w1 * v1[1] + w2 * v2[1]
    z3 = w0 * v0[2] + w1 * v1[2] + w2 * v2[2]

    # noise gradient（向量化）
    gx, gy, _gz = noise_field.gradient(x3, y3, z3)

    # 简化版切线空间法线：tangent≈+X, bitangent≈+Y, normal≈+Z（Blender 几乎水平 mesh）
    nx = -gx
    ny = -gy
    nz = np.ones_like(nx)
    nlen = np.sqrt(nx * nx + ny * ny + nz * nz)
    inv_nlen = np.where(nlen < 1e-9, 0.0, 1.0 / nlen)
    nx *= inv_nlen
    ny *= inv_nlen
    nz *= inv_nlen

    # 编码 [-1, 1] → [0, 255]
    rx = np.clip((nx + 1.0) * 127.5, 0, 255).astype(np.uint8)
    ry = np.clip((ny + 1.0) * 127.5, 0, 255).astype(np.uint8)
    rz = np.clip((nz + 1.0) * 127.5, 0, 255).astype(np.uint8)

    yi = yy[inside]
    xi = xx[inside]
    pixels[yi, xi, 0] = rx[inside]
    pixels[yi, xi, 1] = ry[inside]
    pixels[yi, xi, 2] = rz[inside]


def bake_normal_map(mesh, noise_field: TileableNoiseField, resolution: int) -> np.ndarray:
    """烘焙切线空间法线贴图。

    mesh: Blender bpy.types.Mesh（已有 active uv_layer，顶点 co 即三维位置）。
    返回：(resolution, resolution, 4) uint8 ndarray，RGBA。
      初始 (128, 128, 255, 255) = 切线空间平面法线；UV 三角形覆盖区域被覆写。
    """
    pixels = np.zeros((resolution, resolution, 4), dtype=np.uint8)
    pixels[:, :, 0] = 128  # tangent space x = 0
    pixels[:, :, 1] = 128  # tangent space y = 0
    pixels[:, :, 2] = 255  # tangent space z = 1
    pixels[:, :, 3] = 255  # alpha 不透明

    uv_data = mesh.uv_layers.active.data
    verts = mesh.vertices

    for poly in mesh.polygons:
        loops = list(poly.loop_indices)
        # 三角形扇形分解（loops[0] + loops[k] + loops[k+1]）
        for k in range(1, len(loops) - 1):
            l0, l1, l2 = loops[0], loops[k], loops[k + 1]
            uv0 = uv_data[l0].uv
            uv1 = uv_data[l1].uv
            uv2 = uv_data[l2].uv
            v0 = verts[mesh.loops[l0].vertex_index].co
            v1 = verts[mesh.loops[l1].vertex_index].co
            v2 = verts[mesh.loops[l2].vertex_index].co
            _rasterize_triangle(
                pixels, resolution,
                (uv0[0], uv0[1]), (uv1[0], uv1[1]), (uv2[0], uv2[1]),
                (v0[0], v0[1], v0[2]), (v1[0], v1[1], v1[2]), (v2[0], v2[1], v2[2]),
                noise_field,
            )

    return pixels
